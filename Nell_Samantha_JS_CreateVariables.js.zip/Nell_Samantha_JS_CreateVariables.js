//Declaring a variable (height) and assigning a value x
var height = 42 //where height is >= 42
console.log(height) // printing the value of height to the command terminal

//Declaring a variable (age) and assigning a value y
var age = 11 // where age is >= 11
console.log(age) // printing the value of age to the command terminal


